"build-and-stage-next-gen"
